package test;

import java.util.Scanner;

public class WordSearch {

	public WordSearch() {
		// TODO Auto-generated constructor stub
	}
	
public static boolean find_word(char [][] wordboard, String word,boolean [][] visited)
	{
		if (word.length() == 0)
		{
			return false;
		}
		
		int wbrows = wordboard.length;
		int wbcolumns = wordboard[0].length;
		for (int i = 0; i < wbrows; i++)
		{
			for (int j = 0; j < wbcolumns; j++)
			{
				if (wordboard[i][j] == word.charAt(0))
				{
					visited[i][j] = false;
					if (word_run(wordboard, word, 0, i, j, visited))
					{
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public static boolean word_run(char [][] wordboard, String word, int idx, int i, int j, boolean [][] visited)
	{
		if (!valid(wordboard, i, j) || visited[i][j] || wordboard[i][j] != word.charAt(idx))
		{
			return false;
		}
		if (idx == word.length() - 1)
		{
			return true;
		}
		visited[i][j] = true;
		boolean found = word_run(wordboard, word, idx + 1, i + 1, j, visited) || word_run(wordboard, word, idx + 1, i - 1, j, visited) || word_run(wordboard, word, idx + 1, i, j + 1, visited) || word_run(wordboard, word, idx + 1, i, j - 1, visited);
		
		visited[i][j] = false;
		return found;
	}
	
	public static boolean valid(char[][] wordboard, int i, int j)
	{
		int wbrows = wordboard.length;
		int wbcolumns = wordboard[0].length;
		return (0 <= i && i < wbrows && 0 <= j && j < wbcolumns);
	}
	
	public static void main(String[] args) 
	{
		Scanner userInput = new Scanner(System.in);  // Create a Scanner object
	    System.out.println("Enter a word to search:");

	    String word = userInput.nextLine();
	    
	    
		char [][] wordboard = new char [][] 
		{
			{'A','B','C','E'},
			{'S','F','C','S'},
			{'A','D','E','E'},
		};
			
		
		int wbrows = wordboard.length;
		int wbcolumns = wordboard[0].length;
		
		boolean [][] visited = new boolean[wbrows][wbcolumns];
		for (int i=0;i<wbrows;i++)
		    for (int j=0;j<wbcolumns;j++)
		    {
		        visited[i][j] = false;
		    }
		
		
		System.out.println(find_word(wordboard, word,visited));
    }
}


