package test;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import au.com.bytecode.opencsv.CSVWriter;

public class WebCrawler {

	// Array to store names of properties
	static String[] allTypesArr = null;
	// Array to store values of properties
	static String[] allTypesValArr = null;

	// The main method of this class, which also house all functionality
	public static void main(String[] args) throws IOException {

		// csv file name as "result.csv"
		String csvFilePath = "./result.csv";

		// Web page of issue report
		String url = "https://issues.apache.org/jira/browse/CAMEL-10597";

		// Create a document object, then use JSoup to fetch the website.
		Document doc = Jsoup.connect(url).get();

		// Get all property names as an array
		allTypesArr = getIssueProperties(url, doc);

		// Write property names to CSV file
		writeDataAtOnce(csvFilePath, allTypesArr);

		// Get all property values and write to CSV file
		allTypesValArr = getIssuePropertiesValue(url, doc);
		writeDataAtOnce(csvFilePath, allTypesValArr);

	}

	// This method extract property names from the web page and store property names
	// in an array,"String [] allTypesArr"
	public static String[] getIssueProperties(String url, Document doc) throws IOException {

		// Arrays to store names of properties such as Details, People, Date,
		// Description and Comments
		String[] detailsTypeArr;
		String[] peopleTypeArr;
		String[] dateTypeArr;
		String[] descAndComments;
		String[] allTypesArr;

		// Below we extract information using the elements that hold required
		// information
		// Fetch details of iisue
		Elements detailsElements = doc.getElementsByClass("name");
		String detailType = detailsElements.text();

		// Store extracted info.(types of detail) in an array
		detailsTypeArr = detailType.split(":");

		// Fetch names of people types and store in an array
		Element peopleModule = doc.getElementById("peoplemodule");
		Elements peopleElements = peopleModule.getElementsByTag("dt");
		String peopleType = peopleElements.text();
		peopleTypeArr = peopleType.split(":");

		// Fetch names of date types and store in an array
		Element dateModule = doc.getElementById("datesmodule");
		Elements dateElements = dateModule.getElementsByTag("dt");
		String dateType = dateElements.text();
		dateTypeArr = dateType.split(":");

		// Fetch heading Description
		String description = doc.getElementById("descriptionmodule_heading").text();

		String comments = "Comments";

		descAndComments = new String[2];
		descAndComments[0] = description;
		descAndComments[1] = comments;

		// join all arrays into one single array and return
		allTypesArr = joinArrayGeneric(detailsTypeArr, peopleTypeArr, dateTypeArr, descAndComments);
		return allTypesArr;
	}

	// Get values for properties
	public static String[] getIssuePropertiesValue(String url, Document doc) throws IOException {

		String descriptionValue = null;
		String commentsValue = null;

		// Arrays to store values of properties
		String[] detailsTypeValueArr = null;
		String[] peopleTypeValueArr = null;
		String[] dateTypeValueArr = null;
		String[] allTypesValueArr = null;
		String[] descAndCommentsValueArr = null;

		// Get values of details
		Elements detailsValueElement = doc.getElementsByClass("value");
		detailsTypeValueArr = new String[detailsValueElement.size()];
		// Store details in array
		int i = 0;
		for (Element subDetailsValueElement : detailsValueElement) {
			detailsTypeValueArr[i] = subDetailsValueElement.text();
			i++;
		}

		// Get values for people types and store in an array
		Element peopleModule = doc.getElementById("peoplemodule");
		Elements peopleTypeValue = peopleModule.getElementsByTag("dd");
		peopleTypeValueArr = new String[peopleTypeValue.size()];

		int j = 0;
		for (Element subPeopleValueElement : peopleTypeValue) {
			peopleTypeValueArr[j] = subPeopleValueElement.text();
			j++;
		}

		// Get values for date types and store in an array
		Element dateModule = doc.getElementById("datesmodule");
		Elements dateTypeValue = dateModule.getElementsByTag("dd");
		dateTypeValueArr = new String[dateTypeValue.size()];

		int k = 0;
		for (Element subDateValueElement : dateTypeValue) {
			dateTypeValueArr[k] = subDateValueElement.text();
			k++;
		}

		// Get values for description
		Elements descElements = doc.getElementsByClass("user-content-block");
		for (Element subDescElement : descElements) {
			descriptionValue = subDescElement.text();
		}

		// Get Comments
		Elements scripts = doc.getElementsByTag("script");
		for (Element script : scripts) {
			commentsValue = script.data();
			System.out.println(commentsValue);
		}

		descAndCommentsValueArr = new String[2];
		descAndCommentsValueArr[0] = descriptionValue;
		descAndCommentsValueArr[1] = commentsValue;

		// join all arrays that contain values into one single array and return
		allTypesValueArr = joinArrayGeneric(detailsTypeValueArr, peopleTypeValueArr, dateTypeValueArr,
				descAndCommentsValueArr);
		return allTypesValueArr;
	}

	// to write extracted information to .csv file
	public static void writeDataAtOnce(String filePath, String[] arr) {
		try {
			CSVWriter writer = new CSVWriter(new FileWriter(filePath, true));
			writer.writeNext(arr);
			writer.close();
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Merge multiple arrays
	static <T> T[] joinArrayGeneric(T[]... arrays) {
		int length = 0;
		for (T[] array : arrays) {
			length += array.length;
		}

		final T[] result = (T[]) Array.newInstance(arrays[0].getClass().getComponentType(), length);

		int offset = 0;
		for (T[] array : arrays) {
			System.arraycopy(array, 0, result, offset, array.length);
			offset += array.length;
		}

		return result;
	}

}
